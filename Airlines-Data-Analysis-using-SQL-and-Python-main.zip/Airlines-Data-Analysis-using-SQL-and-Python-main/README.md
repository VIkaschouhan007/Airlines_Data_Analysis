# Airlines Data Analysis using SQL and Python

# Objective:
*  The goal of this data analysis project using SQL would be to identify opportunities to increase the occupancy rate on low-performing flights, which can ultimately lead to increased profitability for the airlines.

# Tools Used:
* Python Programming Language

* Libraries : Sqlite3, Numpy, Pandas, Scikit-learn, Seaborn

* IDE: Jupyter Notebook

* Dashboard: MS Power BI and MS Excel

